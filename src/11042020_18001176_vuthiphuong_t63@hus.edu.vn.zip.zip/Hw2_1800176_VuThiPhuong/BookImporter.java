package Hw2_1800176_VuThiPhuong;

import java.util.Scanner;

public class BookImporter extends BookManager {

	private final int limitedofquantity = 1000;
	private int imported;
	static Scanner sc = new Scanner(System.in);

	public BookImporter() {

	}

	public BookImporter(String title, int amountimport, int currentamount) {
		this.title = title;
		this.amountimport = amountimport;
		this.currentamount = currentamount;
	}

	public BookImporter(String title, int currentamount) {
		this.title = title;
		this.currentamount = currentamount;
	}

	public int getImported() {
		return imported;
	}

	public void setImported(int imported) {
		this.imported = imported;
	}

	public int importBook() {
		int total = 0;
		if (currentamount < limitedofquantity) {
			 total = this.amountimport + imported;
		} else
		 total = this.amountimport;
		return total;
	}

	public int currentAmount() {
		return imported + this.currentamount;
	}
	public void inputImporter() {
		System.out.println("Nhap so luong sach can nhap:");
		this.setImported(Integer.parseInt(sc.nextLine()));
		System.out.println("So luong con trong kho:" + currentamount);

	}

	@Override
	public String toString() {
		return "BookImporter [imported=" + imported + ", totalImported = " + importBook() +", acount after import =" + currentAmount() + "]";
	}

}
