package Hw2_1800176_VuThiPhuong;

import java.util.ArrayList;
import java.util.Scanner;

public class BookManagerTest {
	static Scanner sc = new Scanner(System.in);
// em dang gap loi o ham nay a!
	public static float levelReview(ArrayList<BookManager> manas) {
		BookReviewer reviewer = new BookReviewer();
		int countreview = reviewer.countreview;
		float sum = 0;
		while (countreview != 0) {
			sum = sum + reviewer.getReview();
		}
		return (float) (sum / countreview);
	}

	public static void print(ArrayList<BookManager> manas) {
		for (int i = 0; i < manas.size(); i++) {
			System.out.println(manas.get(i).toString());

		}
	}
	public static void main(String[] args) {

		ArrayList<BookManager> manas = new ArrayList<BookManager>();
	BookManager mana = new BookManager();
		mana.inputBookManager();
		manas.add(mana);
		System.out.println("Nhap so thong tin can quan ly :");
		int n = Integer.parseInt(sc.nextLine());
		for(int i = 0; i < n; i++) {
			System.out.println("Nhap kieu nguoi dung:");
			String name = sc.nextLine();
			if(name.equals("buyer")) {
			BookBuyer buyer = new BookBuyer(manas.get(i).getTitle(),manas.get(i).currentPriceSell(),manas.get(i).getCurrentamount());
			buyer.inputBuyer();
			manas.add(buyer);
			}
			else if(name.equals("reviewer")) {
				BookReviewer reviewer = new BookReviewer(manas.get(i).getTitle(),manas.get(i).currentPriceSell(),manas.get(i).getCurrentamount());
				reviewer.inputReviewer();
				manas.add(reviewer);
			}
			else if(name.equals("importer")) {
				BookImporter importer = new BookImporter(manas.get(i).getTitle(),manas.get(i).getAmountimport(),manas.get(i).getCurrentamount());
				importer.inputImporter();
				manas.add(importer);
			}
		}
		print(manas);
		//System.out.println(levelReview(manas));

	}
}
