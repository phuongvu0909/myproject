package Hw2_1800176_VuThiPhuong;

public class BookSeller extends BookManager {
	 //      - Người bán sách
    //          - Người bán sách có nhiều cấp. Từ cấp 1 cho tới cấp 4
    //          - Hoa hồng cho người bán sách theo cấp độ từ 20% 15% 10% 5% tương ứng 4 cấp
	private int amountsell;
	private int levelseller; 
	
	public BookSeller(int amountsell, int levelseller) {
		this.amountsell = amountsell;
		this.levelseller = levelseller;
	}

	public int getAmountsell() {
		return amountsell;
	}

	public void setAmountsell(int amountsell) {
		this.amountsell = amountsell;
	}

	public int getLevelseller() {
		return levelseller;
	}

	public void setLevelseller(int levelseller) {
		this.levelseller = levelseller;
	}
	
	public int amountremaining() {
		return currentamount - amountsell;
	}
	public float commission() {
		float c = 0;
		if(levelseller == 1)
			 c = 5 / 100;
		else if(levelseller == 2)
			c = 10 / 100;
		else if(levelseller == 3)
			c = 15 /100;
		else 
			c = 20 /100;
		return c;
	}
	
	public float totalComission() {
		float sum = amountsell * commission();
		return sum;
	}
}
