package Hw2_1800176_VuThiPhuong;

import java.util.Scanner;

public class BookReviewer extends BookManager {

	private String cmt;
	private int review;
	private float price = currentPriceSell();
	protected int countreview = 0;
	static Scanner sc = new Scanner(System.in);

	public BookReviewer(String title, float price, int review) {
		this.title = title;
		this.price = price;
		this.review = review;
	}

	public BookReviewer() {
		// TODO Auto-generated constructor stub
	}

	public BookReviewer(String title, float price, int review, String cmt) {
		this.title = title;
		this.price = price;
		this.review = review;
		this.cmt = cmt;
	}

	public String getCmt() {
		return cmt;
	}

	public void setCmt(String cmt) {
		this.cmt = cmt;
	}

	public int getReview() {
		return review;
	}

	public void setReview(int review) {
		countreview++;
		this.review = review;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void inputReviewer() {
		System.out.println("Danh gia(1 den 5 sao):");
		this.review = Integer.parseInt(sc.nextLine());
		System.out.println("Nhan xet sach:");
		this.cmt = sc.nextLine();
	}

	@Override
	public String toString() {
		return "BookReviewer [title=" + title + ", price=" + price + ", review=" + review + ", cmt = " + cmt + "]";
	}

}
