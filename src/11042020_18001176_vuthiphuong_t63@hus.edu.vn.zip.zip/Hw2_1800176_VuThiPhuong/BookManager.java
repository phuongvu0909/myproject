package Hw2_1800176_VuThiPhuong;

import java.util.Scanner;

public class BookManager {
	protected String title;
	protected int price;
	protected int amountimport;
	protected int currentamount;
	protected static Scanner sc = new Scanner(System.in);

	public BookManager() {

	}

	public BookManager(String title, int price, int currentamount) {
		this.title = title;
		this.price = price;
		this.currentamount = currentamount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getAmountimport() {
		return amountimport;
	}

	public void setAmountimport(int amountimport) {
		this.amountimport = amountimport;
	}

	public int getCurrentamount() {
		return currentamount;
	}

	public void setCurrentamount(int currentamount) {
		this.currentamount = currentamount;
	}

	public int totalAmountSell() {
		return amountimport - currentamount;
	}

	public float currentPriceSell() {
		if (currentamount >= 100 && currentamount < 1000) {
			return (float) (price * 0.9);
		} else
			return (float) (price * 0.8);

	}

	public void inputBookManager() {
		System.out.println("Nhap ten sach:");
		this.setTitle(sc.nextLine());
		System.out.println("Nhap gia cua sach:");
		this.setPrice(Integer.parseInt(sc.nextLine()));
		System.out.println("So luong da nhap:");
		this.setAmountimport(Integer.parseInt(sc.nextLine()));
		System.out.println("So luong dang co trong kho:");
		this.setCurrentamount(Integer.parseInt(sc.nextLine()));
	}

	@Override
	public String toString() {
		return "BookManager [title=" + title + ", price=" + price + ", currentPriceSell=" + currentPriceSell()
				+ ", amountimport=" + amountimport + ", currentamount=" + currentamount + ",totalAmountSell:"
				+ totalAmountSell() + "]";
	}

}
