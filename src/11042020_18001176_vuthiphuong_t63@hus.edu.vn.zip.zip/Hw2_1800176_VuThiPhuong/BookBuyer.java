package Hw2_1800176_VuThiPhuong;

import java.util.Scanner;

public class BookBuyer extends BookManager {
//  - Người mua sách
//  - Người mua sách sẽ được giảm giá thêm 3% nếu đã từng mua sách ở đây

	private int amountbuy;
	private int countbuyed;
	private int review;
	private float price = this.currentPriceSell();
	static Scanner sc = new Scanner(System.in);

	public BookBuyer(String title, float price, int currenamount) {
		this.title = title;
		this.price = price;
		this.currentamount = currenamount;
	}

	public BookBuyer(String title, int price, int amountbuy, int review, int countbuyed) {
		this.title = title;
		this.price = price;
		this.amountbuy = amountbuy;
		this.review = review;
		this.countbuyed = countbuyed;

	}

	public int getAmountbuy() {
		return amountbuy;
	}

	public void setAmountbuy(int amountbuy) {
		this.amountbuy = amountbuy;
	}

	public int getCountbuyed() {
		return countbuyed;
	}

	public void setCountbuyed(int countbuyed) {
		this.countbuyed = countbuyed;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getReview() {
		return review;
	}

	public void setReview(int review) {
		this.review = review;
	}

	public boolean checkMember() {
		if (countbuyed > 0)
			return true;
		else
			return false;
	}

	public float currentPriceBuy() {
		float cur = 0;
		if (checkMember() == true) {
			cur = (float) (price * 0.97);
		}
		return cur;
	}

	public void inputBuyer() {
		System.out.println("thong tin nguoi mua:");
		System.out.println("So luong mua:");
		this.setAmountbuy(Integer.parseInt(sc.nextLine()));
		System.out.println("Danh gia sach(1 den 5 sao):");
		this.setReview(Integer.parseInt(sc.nextLine()));
		System.out.println("So lan mua:");
		this.setCountbuyed(Integer.parseInt(sc.nextLine()));
	}

	@Override
	public String toString() {
		return "BookBuyer [ title=" + title + ", currentpricebuy= " + currentPriceBuy() + ", amountbuy=" + amountbuy
				+ ", review=" + review + "]";
	}

}
