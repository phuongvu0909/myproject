package Hw2_1800176_VuThiPhuong;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class BookManagerTest {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		Set<BookManager> manas = new HashSet<BookManager>();
		BookManager book = new BookManager();
		System.out.println("Nhap thong tin sach:");
		inputBook(book);
		System.out.println("Nhap kieu nguoi dung:buyer/reviewer/importer/seller");
		String name = sc.nextLine();
				if (name.equals("buyer")) {
			// buyer:id, amount buy
			BookBuyer buyer1 = new BookBuyer("b11", 12,3);
			BookBuyer buyer2 = new BookBuyer("b11", 13,4);
			manas.add(buyer1);
			manas.add(buyer2);
			System.out.println("Thuc hien tim kiem nguoi dung: id = b11");
			BookBuyer search1 = new BookBuyer("b11");
			System.out.println("Search buyer1:" + manas.contains(search1));

		} else if (name.equals("reviewer")) {
			// String id,String cmt, int review
			BookReviewer reviewer1 = new BookReviewer("r11", "hay", 4);
			BookReviewer reviewer2 = new BookReviewer("r12", "hay", 3);
			manas.add(reviewer1);
			manas.add(reviewer2);

		} else if (name.equals("importer")) {
			// String id,int amountimport
			BookImporter importer1 = new BookImporter("i11", 200);
			BookImporter importer2 = new BookImporter("i12", 100);
			manas.add(importer1);
			manas.add(importer2);
		} else if (name.equals("seller")) {
			// String id, int amountsell, int levelseller
			ArrayList<BookSeller> sellers = new ArrayList<BookSeller>();
			BookSeller seller1 = new BookSeller("s11", 2, 4);
			BookSeller seller2 = new BookSeller("s12", 10, 3);
			sellers.add(seller1);
			sellers.add(seller2);
			for (BookSeller seller : sellers) {
				System.out.println(seller);
			}
			System.out.println("Nguoi ban duoc nhieu sach nhat la:");
			maxsell(sellers);
			System.out.println("Nguoi ban duoc it sach nhat la:");
			minsell(sellers);
		}
		for (BookManager mana : manas) {
			System.out.println(mana);
		}
	}
	public static void maxsell(ArrayList<BookSeller> sellers) {
		int maxamountsell = sellers.get(0).getAmountSell();
		for(int i = 1; i < sellers.size(); i++) {
			if(maxamountsell < sellers.get(i).getAmountSell()) {
				maxamountsell = sellers.get(i).getAmountSell();
			}
		}
		BookSeller searchmaxsell = new BookSeller(maxamountsell);
		if(sellers.contains(searchmaxsell) == true) {
			System.out.println(searchmaxsell.toString());
		}
	}
	
	public static void minsell(ArrayList<BookSeller> sellers) {
		int minamountsell = sellers.get(0).getAmountSell();
		for(int i = 1; i < sellers.size(); i++) {
			if(minamountsell > sellers.get(i).getAmountSell()) {
				minamountsell = sellers.get(i).getAmountSell();
			}
		}
		BookSeller searchminsell = new BookSeller(minamountsell);
		if(sellers.contains(searchminsell) == true) {
			System.out.println(searchminsell.toString());
		}
	}
	
	public static void inputBook(BookManager book) {
		System.out.println("Nhap gia cua sach:");
		book.setPrice(Float.parseFloat(sc.nextLine()));
		System.out.println("Nhap so luong sach:");
		book.setAmount(Integer.parseInt(sc.nextLine()));
	
	}
}
