package Hw2_1800176_VuThiPhuong;

import java.util.Scanner;

public class BookManager {
	private float price;
	private int amount;
	private float rating;
	private int countreview;
	
	static Scanner sc = new Scanner(System.in);

	public BookManager() {

	}

	public BookManager(float price, int amount) {
		this.price = price;
		this.amount = amount;
	}

	public BookManager(float price, int amount, float rating, int countreview) {
		this.price = price;
		this.amount = amount;
		this.rating = rating;
		this.countreview = countreview;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public int getCountreview() {
		return countreview;
	}

	public void setCountreview(int countreview) {
		this.countreview = countreview;
	}
	
	@Override
	public String toString() {
		return "BookManager [price=" + price + ", amount=" + amount + ", rating=" + getRating() + ", countreview="
				+ getCountreview() + "]";
	}

	
}
