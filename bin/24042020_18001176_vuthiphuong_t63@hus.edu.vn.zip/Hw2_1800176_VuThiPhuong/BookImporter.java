package Hw2_1800176_VuThiPhuong;

public class BookImporter extends BookManager {

	private final int limitedofquantity = 1000;
	private int amountimport;
	private String id;

	public BookImporter() {

	}

	public BookImporter(String id,int amountimport) {
		this.id = id;
		this.amountimport = amountimport;
	}

	public int getAmountimport() {
		return amountimport;
	}

	public void setAmountimport(int amountimport) {
		this.amountimport = amountimport;
	}

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean importBook(BookManager book, int amountimport) {
		if (book.getAmount() >= limitedofquantity) {
			return false;
		} else {
			book.setAmount(book.getAmount() + amountimport);
			return true;
		}

	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof BookImporter))
			return false;
		BookImporter other = (BookImporter) obj;
		return this.id == other.id;
	}

	@Override
	public String toString() {
		return "BookImporter [id=" + id + ",amountimport= " + amountimport + "]";
	}

	
	
}
