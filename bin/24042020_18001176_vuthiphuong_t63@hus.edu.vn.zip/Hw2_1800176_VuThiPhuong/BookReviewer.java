package Hw2_1800176_VuThiPhuong;

public class BookReviewer extends BookManager {

	private String cmt;
	private int review;
	private String id;

	public BookReviewer() {

	}

	public BookReviewer(String id,String cmt, int review) {
		this.id = id;
		this.cmt = cmt;
		this.review = review;
	}

	public String getCmt() {
		return cmt;
	}

	public void setCmt(String cmt) {
		this.cmt = cmt;
	}

	public int getReview() {
		return review;
	}

	public void setReview(int review) {
		this.review = review;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void reviewBook(BookManager book, int review) {
		float newrating = (book.getRating() * book.getCountreview() + review) / (book.getCountreview()+ 1);
		book.setRating(newrating);
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof BookReviewer))
			return false;
		BookReviewer other = (BookReviewer) obj;
		return this.id == other.id;
	}

	@Override
	public String toString() {
		return "BookReviewer [id=" + id + ", review=" + review + ",cmt= " + cmt + "]";
	}

	

}
