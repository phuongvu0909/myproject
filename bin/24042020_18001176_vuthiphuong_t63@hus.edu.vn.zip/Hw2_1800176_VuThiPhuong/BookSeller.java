package Hw2_1800176_VuThiPhuong;

public class BookSeller extends BookManager {
	// - Người bán sách bán cho người mua sách và hoa hồng cũng dựa vào giá thực tế
	// của người mua sách
	// - Người bán sách có nhiều cấp. Từ cấp 1 cho tới cấp 4
	// - Hoa hồng cho người bán sách theo cấp độ từ 20% 15% 10% 5% tương ứng 4 cấp
	private int amountsell;
	private int levelseller;
	private float commission;
	private String id;

	public BookSeller() {
		
	}
	
	public BookSeller(int amountsell) {
		this.amountsell = amountsell;
	}
	public BookSeller(String id, int amountsell, int levelseller) {
		this.id = id;
		this.amountsell = amountsell;
		this.levelseller = levelseller;
	}

	public int getAmountSell() {
		return amountsell;
	}

	public void setAmountSell(int amountsell) {
		this.amountsell = amountsell;
	}

	public float getCommission() {
		return commission;
	}

	public void setCommission(float commission) {
		this.commission = commission;
	}

	public int getLevelseller() {
		return levelseller;
	}

	public void setLevelseller(int levelseller) {
		this.levelseller = levelseller;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean sellBook(BookManager book, int amountsell, BookBuyer buyer) {
		if (buyer.getAmountbuy() > book.getAmount())
			return false;
		else {
			int discount = 0;
			switch (levelseller) {
			case 1:
				discount = 20;
				break;
			case 2:
				discount = 15;
				break;
			case 3:
				discount = 10;
				break;
			case 4:
				discount = 5;
				break;
			default:
				discount = 0;
				break;
			}
			float totalprice = book.getPrice() * amountsell;
			if (book.getAmount() > 100) {
				totalprice = totalprice - totalprice * 10 / 100;
			} else
				totalprice = totalprice - totalprice * 20 / 100;

			if (buyer.isUsedtobuy() == true) {
				float downprice = book.getPrice() * 3 / 100;
				totalprice = totalprice - downprice;
			}
			commission += totalprice * discount / 100;
			return true;
		}
	}

	public void updateAmountSell(int newamountsell) {
		int updateamountsell = getAmountSell() + amountsell;
		setAmountSell(updateamountsell);
	}

	public void updateLevel(int levelseller) {
		if (getAmountSell() > 0 && getAmountSell() < 1000) {
			setLevelseller(levelseller);
		} else if (getAmountSell() > 1000 && getAmountSell() < 2000) {
			while (levelseller > 3) {
				levelseller--;
			}
			setLevelseller(levelseller);
		} else if (getAmountSell() > 2000 && getAmountSell() < 4000) {
			while (levelseller > 2)
				levelseller--;
			setLevelseller(levelseller);
		} else {
			while (levelseller > 1)
				levelseller--;
			setLevelseller(levelseller);
		}
	}

	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof BookSeller))
			return false;
		BookSeller other = (BookSeller) obj;
		return this.id == other.id;
	}

	@Override
	public String toString() {
		return "BookSeller [id=" + id + ", levelseller=" + getLevelseller() + ",amountsell= " + getAmountSell()  + "]";
	}
	
	
}
