package Hw2_1800176_VuThiPhuong;

import java.util.ArrayList;
import java.util.Scanner;

public class BookBuyer extends BookManager {
//  - Người mua sách của người bán,được review
//  - Người mua sách sẽ được giảm giá thêm 3% nếu đã từng mua sách ở đây

	private int amountbuy;
	private float totalpricemustpay;
	private int review;
	private String id;
	
	static Scanner sc = new Scanner(System.in);

	public BookBuyer(String id) {
		this.id = id;
	}
	public BookBuyer(String id,int amountbuy,int review) {
		this.id = id;
		this.amountbuy = amountbuy;
	}

	public BookBuyer() {
	}

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public int getAmountbuy() {
		return amountbuy;
	}

	public void setAmountbuy(int amountbuy) {
		this.amountbuy = amountbuy;
	}

	public float getTotalpricemustpay() {
		return totalpricemustpay;
	}

	public void setTotalpricemustpay(float totalpricemustpay) {
		this.totalpricemustpay = totalpricemustpay;
	}

	public int getReview() {
		return review;
	}

	public void setReview(int review) {
		this.review = review;
	}

	public void reviewBookOfBuy(BookManager book, int review) {
		float newrating = (book.getRating() * book.getCountreview() + review) / (book.getCountreview()+ 1);
		book.setRating(newrating);
	}

	public boolean isUsedtobuy() {
		ArrayList<BookBuyer> buyers = new ArrayList<BookBuyer>();
		for(int i = 0; i < buyers.size(); i++) {
			if(buyers.get(i).getId().contains(id)) {
				return true;
			}
		}
		return false;
	}
	public void buyBook(BookManager book, int amountbuy, BookSeller seller) {
		float totalPrice = book.getPrice() * amountbuy;
		if (book.getAmount() > 100) {
			totalPrice = totalPrice - totalPrice * 10 / 100;
		} else
			totalPrice = totalPrice - totalPrice * 20 / 100;
		if (! isUsedtobuy()) {
			totalpricemustpay += totalPrice;
		} else {
			totalpricemustpay += totalPrice * 97 / 100;
		}
	}
	public void reviewBook(BookManager book, int review) {
		float newrating = (book.getRating() * book.getCountreview() + review) / (book.getCountreview()+ 1);
		book.setRating(newrating);
	}
	
	@Override
	public int hashCode() {
		return id.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof BookBuyer))
			return false;
		BookBuyer other = (BookBuyer) obj;
		return this.id == other.id ;
	}
	
	public void input(BookBuyer buyer) {
		System.out.println("Nhap id:");
		buyer.setId(sc.nextLine());
		System.out.println("So luong mua:");
		buyer.setAmountbuy(Integer.parseInt(sc.nextLine()));
	}

	@Override
	public String toString() {
		return "BookBuyer [id=" + id + ", totalpricemustpay=" + getTotalpricemustpay() + ", review=" + getReview()
				+ ", amountbuy=" + amountbuy + "]";
	}
	

}
	